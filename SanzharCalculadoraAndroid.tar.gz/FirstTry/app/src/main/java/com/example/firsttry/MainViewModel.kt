package com.example.firsttry
import android.util.Log

import androidx.lifecycle.ViewModel


class MainViewModel: ViewModel() {

    // Dependencies
    val calculatorBrain = CalculatorBrain()

    // View state
    var currentInput: String = ""

    fun inputNumber (number: String){
        currentInput += number
    }

    // Task methods
    fun compute(): String {
        currentInput = calculatorBrain.compute(currentInput)
        Log.i("MyTag", "finishedCompute")
        return currentInput
    }

    fun clearInput() {
        currentInput = ""
    }

}