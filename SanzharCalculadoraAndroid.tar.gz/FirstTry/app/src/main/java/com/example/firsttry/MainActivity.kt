package com.example.firsttry

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.ViewModelProvider
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)


        //Log.i("asdff", "hi therejxcvxcvxcvx")
        textView2.setText("0")
        textView3.setText(viewModel.currentInput)
        //=
        button17.setOnClickListener {
            textView2.setText(viewModel.compute())
            viewModel.clearInput()
        }
        //C
        button15.setOnClickListener {
            //viewModel.clearInput()
            textView3.setText(viewModel.currentInput)

        }

// wrong format. division by 0 or infiinity. doubles.
//first number negative
        val buttonListener: View.OnClickListener = View.OnClickListener {
            viewModel.inputNumber((it as Button).text.toString())
            textView3.setText(viewModel.currentInput)
        }
        listOf(button1, button2, button3, button4, button5, button6, button7, button8, button9,
            button11, button12, button13, button14, button16).forEach { it.setOnClickListener(buttonListener)}


    }

    private fun stringSum(myString: String): Int {
        val myStringArray = myString.split(" ")
        val first = myStringArray[0].toInt()
        val second = myStringArray[2].toInt()
        if (myStringArray[1] == "+") return first + second
        if (myStringArray[1] == "/") return first / second
        if (myStringArray[1] == "*") return first * second
        if (myStringArray[1] == "-") return first - second
        return -1

    }
}
